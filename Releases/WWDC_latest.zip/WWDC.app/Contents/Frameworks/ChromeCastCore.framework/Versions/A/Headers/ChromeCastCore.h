//
//  ChromeCastCore.h
//  ChromeCastCore
//
//  Created by Guilherme Rambo on 19/10/16.
//  Copyright © 2016 Guilherme Rambo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for ChromeCastCore.
FOUNDATION_EXPORT double ChromeCastCoreVersionNumber;

//! Project version string for ChromeCastCore.
FOUNDATION_EXPORT const unsigned char ChromeCastCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ChromeCastCore/PublicHeader.h>

#import <ChromeCastCore/CASTV2PlatformReader.h>
