//
//  Siesta.h
//  Siesta
//
//  Created by Paul on 2015/6/14.
//  Copyright © 2016 Bust Out Solutions. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Siesta.
FOUNDATION_EXPORT double SiestaVersionNumber;

//! Project version string for Siesta.
FOUNDATION_EXPORT const unsigned char SiestaVersionString[];

