//
//  CloudKitCodable.h
//  CloudKitCodable
//
//  Created by Guilherme Rambo on 11/05/18.
//  Copyright © 2018 Guilherme Rambo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for CloudKitCodable.
FOUNDATION_EXPORT double CloudKitCodableVersionNumber;

//! Project version string for CloudKitCodable.
FOUNDATION_EXPORT const unsigned char CloudKitCodableVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CloudKitCodable/PublicHeader.h>


